window.onload = function() {
	// Form Reset
	$('#reset-form').on('click', function() {
		$('#myForm').trigger("reset");
	});


	var fnameCheck = false;
	var paddressCheck = false;
	var emailCheck = false;
	var phoneCheck = false;
	var passwordCheck = false;
	var cpasswordCheck = false;

	$.fn.enableRegister = function() {
		if ((fnameCheck == true) && (paddressCheck == true) && (emailCheck == true) && (phoneCheck == true) && (passwordCheck == true) && (cpasswordCheck == true)) {
			$('#register').removeAttr("disabled");
		} else {
			$('#register').attr("disabled", "true");
		}
	}

	$('#register').on('click', function() {
		$.fn.appendvalue();
	});

	$.fn.appendvalue = function() {
		var ul = $('#dashboard');
		var fstName = $('#firstName').val();
		var lastName = $('#lastName').val();
		var email = $('#email').val();
		var li = $("<li></li>", {
			class: "dashboard-content"
		});

		var a = $("<div></div>", {
			class: "dashboard-content-name",
			href: "#"
		}).text(fstName + " " + lastName);

		var div = $("<a></a>", {
			class: "dashboard-content-email"
		}).text(email);

		li.append(a);
		li.append(div);
		ul.append(li);
	}

	// First Name
	$('#firstName').on('change', function() {
		$.fn.checkName();
	});

	$.fn.checkName = function() {
		if ($('#firstName').val().indexOf('') > 0) {
			alert("First Name cannot contain spaces or blanks");
			fnameCheck = false;
			$.fn.enableRegister();
		} else {
			fnameCheck = true;
			$.fn.enableRegister();
		}
		return true;
	}


	// Address
	$('#check').on('click', function() {
		$.fn.copyAddress();
	});

	$.fn.copyAddress = function() {
		if ($('#check').is(':checked')) {
			$('#address').attr('disabled', true);
			$('#address').attr('value', $('#permanent').val());
		} else {
			$("#address").attr("disabled", false);
			$("#address").attr("value", "");
		}
	}

	$('#permanent').on('change', function() {
		$.fn.checkPermanentAddress();
	});

	$.fn.checkPermanentAddress = function() {
		var address = $('#permanent').val();
		if (address == null || address == "") {
			alert("Address cannot be empty");
			paddressCheck = false;
			$.fn.enableRegister();
		} else {
			paddressCheck = true;
			$.fn.enableRegister();
		}
		return true;
	}


	// Email
	$('#email').on('change', function() {
		$.fn.checkEmail();
	});

	$.fn.checkEmail = function() {
		var str = $('#email').val();
		var pattern = new RegExp("[a-z0-9._%]+@[a-z0-9]+\.[a-z]{2,3}");
		var response = pattern.test(str);
		if (response == false) {
			alert("Not a valid email id");
			emailCheck = false;
			$.fn.enableRegister();
		} else {
			emailCheck = true;
			$.fn.enableRegister();
		}
		return true;
	}


	// Phone
	$('#phone').on('change', function() {
		$.fn.checkPhone();
	});

	$.fn.checkPhone = function() {
		var str = $('#phone').val();
		var strlen = str.length;
		var pattern = new RegExp("[0-9]");
		var response = pattern.test(str);
		if (response == false || strlen < 10 || strlen > 10) {
			alert("Phone number must be 10 digits long and contain numbers only.");
			phoneCheck = false;
			$.fn.enableRegister();
		} else {
			phoneCheck = true;
			$.fn.enableRegister();
		}
		return true;
	}


	// Password
	$('#password').on('change', function() {
		$.fn.checkPassword();
	});

	$.fn.checkPassword = function() {
		var str = $('#password').val();
		var strlen = str.length;
		var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/;
		var response = re.test(str);
		if (response == false || strlen < 8) {
			alert("Password must contain atleast 8 characters and an uppercase, a number and a special character");
			passwordCheck = false;
			$.fn.enableRegister();
		} else {
			passwordCheck = true;
			$.fn.enableRegister();
		}
		return true;
	}


	$('#cpassword').on('change', function() {
		$.fn.checkConfirmPassword();
	})

	$.fn.checkConfirmPassword = function() {
		var str1 = $('#password').val();
		var str2 = $('#cpassword').val();
		if (str1 != str2) {
			alert("password not matched");
			cpasswordCheck = false;
			$.fn.enableRegister();
		} else {
			cpasswordCheck = true;
			$.fn.enableRegister();
		}
		return true;
	}

}