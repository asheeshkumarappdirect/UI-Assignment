function formReset() {
	document.getElementById("myForm").reset();
}


window.onload = function() {

	var fnameCheck = false;
	var paddressCheck = false;
	var emailCheck = false;
	var phoneCheck = false;
	var passwordCheck = false;
	var cpasswordCheck = false;


	function enableRegister() {
		var register = document.getElementById("register");
		if ((fnameCheck == true) && (paddressCheck == true) && (emailCheck == true) && (phoneCheck == true) && (passwordCheck == true) && (cpasswordCheck == true)) {
			register.removeAttribute("disabled");
		} else {
			register.setAttribute("disabled", true);
		}
	}
	document.getElementById("register").onclick = function() {
		append();
	}

	function append() {
		var ul = document.getElementById("dashboard");
		var fstName = document.getElementById('firstName').value;
		var lastName = document.getElementById('lastName').value;
		var email = document.getElementById('email').value;
		var para = document.createElement("li");
		var fullName = fstName + " " + lastName;
		var Name = document.createTextNode(fullName);
		para.appendChild(Name);
		para.setAttribute("title", email);
		para.setAttribute("style", "text-align:center;");
		var element = document.getElementById("dashboard");
		element.appendChild(para);

	}

	document.getElementById("firstName").onchange = function() {
		checkName();
	}

	function checkName() {
		var fname = document.getElementById("firstName").value;
		if (fname.indexOf('') > 0 || fname == "") {
			alert("First Name cannot contain spaces or blanks");
			fnameCheck = false;
			enableRegister();
		} else {
			fnameCheck = true;
			enableRegister();
		}
		return true;
	}

	document.getElementById('check').onclick = function() {
		copyAddress();
	}

	function copyAddress() {
		if (document.getElementById("check").checked) {
			document.getElementById("address").value = document.getElementById("permanent").value;
		} else {
			document.getElementById("address").value = "";
		}
	}

	document.getElementById('permanent').onchange = function() {
		checkPermanentAddress();
	}

	function checkPermanentAddress() {
		var address = document.getElementById("permanent").value;
		if (address == null || address == "") {
			alert("Address cannot be empty");
			paddressCheck = false;
			enableRegister();
		} else {
			paddressCheck = true;
			enableRegister();
		}
		return true;
	}
	document.getElementById('address').onchange = function() {
		checkCurrentAddress();
	}

	document.getElementById('email').onchange = function() {
		checkEMail();
	}

	function checkEMail() {
		var str = document.getElementById("email").value
		var pattern = new RegExp("[a-z0-9._%]+@[a-z0-9]+\.[a-z]{2,3}");
		var response = pattern.test(str);
		if (response == false) {
			alert("Not a valid email id");
			emailCheck = false;
			enableRegister();
		} else {
			emailCheck = true;
			enableRegister();
		}
		return true;
	}

	document.getElementById('phone').onchange = function() {
		checkPhone();
	}


	function checkPhone() {
		var str = document.getElementById("phone").value
		var strlen = str.length;
		var pattern = new RegExp("[0-9]");
		var response = pattern.test(str);
		if (response == false || strlen < 10 || strlen > 10) {
			alert("Phone number must be 10 digits long and contain numbers only.");
			phoneCheck = false;
			enableRegister();
		} else {
			phoneCheck = true;
			enableRegister();
		}
		return true;
	}

	document.getElementById('password').onchange = function() {
		checkPassword();
	}

	function checkPassword() {
		var str = document.getElementById("password").value
		var strlen = str.length;
		var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/;
		var response = re.test(str);
		if (response == false || strlen < 8) {
			alert("Password must contain atleast 8 characters and an uppercase, a number and a special character");
			passwordCheck = false;
			enableRegister();
		} else {
			passwordCheck = true;
			enableRegister();
		}
		return true;
	}

	document.getElementById('cpassword').onchange = function() {
		checkConfirmPassword();
	}

	function checkConfirmPassword() {
		var str1 = document.getElementById("password").value
		var str2 = document.getElementById("cpassword").value
		if (str1 != str2) {
			alert("password not matched");
			cpasswordCheck = false;
			enableRegister();
		} else {
			cpasswordCheck = true;
			enableRegister();
		}
		return true;
	}

}